<p align="center">
  <a href="https://zuplo.com">
    <img src="https://portal.zuplo.com/zuplo.svg" height="96">
    <h3 align="center">Zuplo</h3>
  </a>
</p>
<p align="center">Zuplo's API Gateway helps small and large teams get APIs to production that are
fast, secure and with game-changing Developer Experience.</p>

# Zuplo CLI

The command-line interface for Zuplo.

```
zuplo <command>

Commands:
  zuplo convert   Converts routes.json to routes.oas.json
  zuplo delete    Deletes the Zuplo API at the URL
  zuplo deploy    Deploys current Git branch of the current directory
  zuplo dev       Runs the Zuplo API locally
  zuplo list      Lists all deployed Zuplo APIs
  zuplo link      Links information from your Zuplo account to your local machine
  zuplo login     Authenticates the user
  zuplo test      Runs the tests under /tests against an endpoint
  zuplo openapi   OpenAPI commands (aliases: oas, open-api)
  zuplo project   Project management commands
  zuplo proxies   Proxy configuration commands
  zuplo source    Source code management commands
  zuplo tunnel    Tunnel commands
  zuplo variable  Variable commands

zuplo openapi

OpenAPI commands

Commands:
  zuplo openapi convert   Convert OpenAPI files between JSON and YAML formats
  zuplo openapi merge     Merge an OpenAPI file into your Zuplo project
  zuplo openapi overlay   Apply an OpenAPI Overlay to an OpenAPI document

Aliases: oas, open-api

zuplo project

Project management commands

Commands:
  zuplo project create  Creates a new project in your account

zuplo proxies

Proxy configuration commands

Commands:
  zuplo proxies create    Creates a new proxy configuration for a fleet
  zuplo proxies update    Updates an existing proxy configuration for a fleet
  zuplo proxies describe  Describes a proxy configuration for a fleet
  zuplo proxies delete    Deletes a proxy configuration for a fleet

zuplo source

Source code management commands

Commands:
  zuplo source upgrade          Updates your project structure to the latest conventions
  zuplo source migrate          Migration commands
    zuplo source migrate dev-portal  Migrates legacy dev portal configuration to new format

zuplo tunnel

Tunnel commands

Commands:
  zuplo tunnel create        Creates a new tunnel in your account
  zuplo tunnel delete        Deletes a tunnel in your account
  zuplo tunnel describe      Describes a tunnel in your account
  zuplo tunnel list          Lists the tunnels in your account
  zuplo tunnel rotate-token  Rotates the token for a tunnel in your account
  zuplo tunnel services      Tunnel services commands

zuplo tunnel services

Tunnel services commands

Commands:
  zuplo tunnel services describe  Describes the services for this tunnel
  zuplo tunnel services update    Updates the services for this tunnel

zuplo variable

Variable commands

Commands:
  zuplo variable create      Creates a new variable for a branch
  zuplo variable update      Updates an existing variable for a branch

```

# Changelog

## v3

- Version 3 requires Node.js 20. Critical bug fixes will be provided for v2
  (using Node.js 18) until September 30, 2024. We encourage you to upgrade to v3
  as soon as possible.

## v2

- Removes the use of Deno's test runner. We now use the built-in test runner in
  Node.js. All features are preserved; however, the output of `zuplo test`
  follows the Node.js
  [spec reporter](https://nodejs.org/docs/latest-v18.x/api/test.html#test-reporters).
