#!/usr/bin/env -S node --no-warnings

process.removeAllListeners("warning");
import "./dist/cli.js";
