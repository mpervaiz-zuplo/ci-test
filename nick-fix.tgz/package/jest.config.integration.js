/**
 * Jest configuration for CLI integration tests
 */
export default {
  preset: "ts-jest/presets/default-esm",
  extensionsToTreatAsEsm: [".ts"],
  testEnvironment: "node",
  testMatch: ["**/src/__tests__/integration/**/*.integration.test.ts"],
  collectCoverageFrom: ["src/**/*.ts", "!src/**/*.d.ts", "!src/__tests__/**/*"],
  transform: {
    "^.+\\.ts$": [
      "ts-jest",
      {
        useESM: true,
        tsconfig: {
          module: "ESNext",
          moduleResolution: "node",
        },
      },
    ],
  },
  moduleNameMapper: {
    "^(\\.{1,2}/.*)\\.js$": "$1",
  },
  transformIgnorePatterns: ["node_modules/(?!.*)"],
  setupFiles: ["<rootDir>/src/__tests__/integration/jest-mocks-setup.ts"],
  setupFilesAfterEnv: ["<rootDir>/src/__tests__/integration/jest-setup.ts"],
  testTimeout: 30000,
  clearMocks: true,
  restoreMocks: true,
  silent: true,
};
